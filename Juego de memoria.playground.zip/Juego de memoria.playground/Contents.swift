import UIKit


for i in 0...100 {
    if i % 5 == 0 {
        print("#\(i) Bingo!!!")
    } else if i % 2 == 0{
        print("#\(i) es par!!!")
    } else if i % 2 != 0{
        print("#\(i) es impar!!!")
    }
    switch i {
    case 30...40:
        print("#\(i) VIVA SWIFT!!!")
    default:
        print("")
    }
}

